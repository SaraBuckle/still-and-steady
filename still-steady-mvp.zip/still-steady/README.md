# Still & Steady — MVP
A free, static, mobile-first Scripture encouragement web app. Two separate experiences: adults and parent-guided children. No accounts, trackers, cookies, AI API calls, or backend required.

## Run locally
Open `index.html` in a browser. For a local web server: `python -m http.server 8000` and visit http://localhost:8000.

## Deploy free
Create a GitHub repository with these three files and enable GitHub Pages (Settings > Pages > Deploy from branch). Alternatively upload the folder to a free static hosting service, subject to its terms and limits. HTTPS is recommended for sharing and home-screen installation. No custom domain is required.

## MVP boundaries
All Scripture quotations are King James Version (public domain). Check wording against a trusted KJV edition before production launch. Daily encouragement rotates based on UTC day and is not personalized. AI was used during content authoring, not during visitor sessions. No live AI chat, push reminders, audio or offline support yet. Child content is intended for parent-guided use. Site is not clinical treatment or emergency support.

## Future roadmap
1. Editorial review by a faith leader and child wellbeing specialist.
2. Add more topics and a search function; audit accessibility and child safety.
3. Add optional browser-local favourites and shareable cards.
4. Add accessible audio and optional reminders with user opt-in.
5. Consider moderated, retrieval-grounded AI only after evaluating cost, privacy, and safety.
